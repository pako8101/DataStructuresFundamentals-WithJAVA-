package craftsmanLab.core;

import craftsmanLab.models.ApartmentRenovation;
import craftsmanLab.models.Craftsman;

import java.util.Collection;

public class CraftsmanLabImpl implements CraftsmanLab {
    @Override
    public void addApartment(ApartmentRenovation job) {

    }

    @Override
    public void addCraftsman(Craftsman craftsman) {

    }

    @Override
    public boolean exists(ApartmentRenovation job) {
        return false;
    }

    @Override
    public boolean exists(Craftsman craftsman) {
        return false;
    }

    @Override
    public void removeCraftsman(Craftsman craftsman) {

    }

    @Override
    public Collection<Craftsman> getAllCraftsmen() {
        return null;
    }

    @Override
    public void assignRenovations() {

    }

    @Override
    public Craftsman getContractor(ApartmentRenovation job) {
        return null;
    }

    @Override
    public Craftsman getLeastProfitable() {
        return null;
    }

    @Override
    public Collection<ApartmentRenovation> getApartmentsByRenovationCost() {
        return null;
    }

    @Override
    public Collection<ApartmentRenovation> getMostUrgentRenovations(int limit) {
        return null;
    }
}
